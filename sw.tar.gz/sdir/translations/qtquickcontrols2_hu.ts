<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu_HU">
<context>
    <name>QtLabsMaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>Az anyag egy csatolt tulajdonság</translation>
    </message>
</context>
<context>
    <name>QtLabsUniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>Az univerzális egy csatolt tulajdonság</translation>
    </message>
</context>
</TS>
